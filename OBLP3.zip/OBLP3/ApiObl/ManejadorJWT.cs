﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Excepciones;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace ApiObl
{
    public class ManejadorJWT
    {
        private static ILoginCS login { get; set; }
       
        public ManejadorJWT(ILoginCS obtenerUsuario)
        {
            login = obtenerUsuario;
        }
        public static DTOUsuario ObtenerUsuario(DTOUsuario nombreUsuario)
        {
            DTOUsuario retorno = login.Login(nombreUsuario.Email,nombreUsuario.Password);

            return retorno;
        }

        public static string GenerarToken(DTOUsuario usuario, IConfiguration configuracion)
        {
            if (usuario == null)
            {
                throw new InvalidUsuarioException("Usuario no existe");
            }
            List<Claim> claims = new List<Claim>() {
                new Claim(ClaimTypes.Email, usuario.Email)
            };

            var claveSecreta = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(configuracion.GetSection("AppSettings:SecretTokenKey").Value!));

            var credenciales = new SigningCredentials(claveSecreta, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(claims: claims, expires: DateTime.Now.AddDays(1), signingCredentials: credenciales);

            var jwtToken = new JwtSecurityTokenHandler().WriteToken(token);

            return jwtToken;
        }
    }
}

