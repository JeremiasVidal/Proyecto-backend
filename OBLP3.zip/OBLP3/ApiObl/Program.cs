using AccesoDatos.SQL;
using LogicaAplicacion.CasosUso;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Filters;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers().ConfigureApiBehaviorOptions(options =>
{
    options.SuppressModelStateInvalidFilter = true;
    options.SuppressMapClientErrors = true;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
var rutaArchivo = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ApiObl.xml");
builder.Services.AddSwaggerGen(opciones =>
{
    //Se agrega la opcion de autenticarse en Swagger
    opciones.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme()
    {
        Description = "Autorizacion estandar mediante esquema Bearer",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey
    });


    opciones.OperationFilter<SecurityRequirementsOperationFilter>();

    opciones.IncludeXmlComments(rutaArchivo);


    opciones.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Documentaci�n de obligatorio 2 de programaci�n 3",
        Description = "Aqui se encuentran todos los endpoint activos para utilizar las funcionalidades requeridas del obligatorio",
        Version = "v1"
    });


});



// Configurar de la autenticacion
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(opciones =>
{
    opciones.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(builder.Configuration.GetSection("AppSettings:SecretTokenKey").Value!)),
        ValidateIssuer = false,
        ValidateAudience = false,
    };
});

builder.Services.AddControllersWithViews();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession();
builder.Services.AddScoped<IUsuarioRepositorio, SqlUsuarioRepositorio>();
builder.Services.AddScoped<IConfiguracionRepositorio, SqlConfiguracionRepositorio>();
builder.Services.AddScoped<ICabaniaRepositorio, SqlCabaniaRepositorio>();
builder.Services.AddScoped<ITipoCabaniaRepositorio, SqlTipoCabaniaRepositorio>();
builder.Services.AddScoped<IMantenimientoRepositorio, SqlMantenimientoRepositorio>();
builder.Services.AddScoped<ILoginCS, LoginCS>();
builder.Services.AddScoped<ICrearMantenimientoCS, CrearMantenimientoCS>();
builder.Services.AddScoped<IGetMantenimientosEntreFechasCS, GetMantenimientosEntreFechasCS>();
builder.Services.AddScoped<IGetCabaniaDeMantenimientoCS, GetCabaniaDeMantenimientoCS>();
builder.Services.AddScoped<IGetTiposCabaniasCS, GetTiposCabaniasCS>();
builder.Services.AddScoped<ICreateTipoCabaniaCS, CreateTipoCabaniaCS>();
builder.Services.AddScoped<IDeleteTipoCabaniaCS, DeleteTipoCabaniaCS>();
builder.Services.AddScoped<IEditTipoCabaniaCS, EditTipoCabaniaCS>();
builder.Services.AddScoped<IFiltrosCabaniasCS, FiltrosCabaniasCS>();
builder.Services.AddScoped<ICreateCabaniaCS, CreateCabaniaCS>();
builder.Services.AddScoped<IMantenimientoPorMontoCS, MantenimientosPorMontoCS>();


builder.Services.AddAuthorization(opciones =>
{
    opciones.DefaultPolicy = new AuthorizationPolicyBuilder()
    .RequireAuthenticatedUser()
    .Build();
});



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
