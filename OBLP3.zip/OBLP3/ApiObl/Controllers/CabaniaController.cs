﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiObl.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    [ApiConventionType(typeof(DefaultApiConventions))]
    public class CabaniaController : Controller
    {
        private ICreateCabaniaCS AgregarCabania;
        private IConfiguracionRepositorio config;
        private IFiltrosCabaniasCS filtros;


        public CabaniaController(ICreateCabaniaCS agregarCabania, IConfiguracionRepositorio config, IFiltrosCabaniasCS filtros)
        {
            this.AgregarCabania = agregarCabania;
            this.config = config;
            this.filtros = filtros;
        }



        /// <summary>
        /// Función que permite crear una cabaña
        /// </summary>
        /// <param name="cab">Se verifican que los datos ingresados sean correctos</param>
        /// <returns>retorna la cabaña creada</returns>
        [HttpPost("/Cabania/Crear")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Crear(DTOCabania cab)
        {
            try
            {
                Uri url = new Uri("https://localhost:7079/Cabania/Crear");

                return Created(url, AgregarCabania.Create(cab));
            }
            catch (InvalidCabaniaException ex)
            {

                return BadRequest(ex.Message);
            }



        }
        /// <summary>
        /// Función que permite listar todas las cabañas
        /// </summary>
        /// <returns>retorna lista cabañas</returns>
        [HttpGet("/Cabania/Listar")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarCabanias()
        {
            try
            {
                var cabanias = filtros.List();
                return Ok(cabanias);
            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        /// <summary>
        /// Función que permite listar todas las cabañas habilitadas
        /// </summary>
        /// <returns>retorna lista cabañas habilitada</returns>

        [HttpGet("/Cabania/Listar/filtros/habilitada")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarCabaniasHabilitadas()
        {

            try
            {
                return Ok(filtros.GetCabaniasHabilitadas());

            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }



        /// <summary>
        ///  Función que permite listar todas las cabañas por nombre
        /// </summary>
        /// <param name="nombre">se buscan las cabañas con ese nombre</param>
        /// <returns>retorna lista cabañas por nombre</returns>

        [HttpGet("/Cabania/Listar/filtros/nombre/{nombre}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarCabaniasPorNombre(string nombre)
        {

            try
            {
                return Ok(filtros.GetCabaniasPorNombre(nombre));

            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }


        }




        /// <summary>
        ///  Función que permite listar todas las cabañas por tipo
        /// </summary>
        /// <param name="nombre">se buscan las cabañas con el nombre del tipo cabaña</param>
        /// <returns>retorna lista cabañas por tipo</returns>

        [HttpGet("/Cabania/Listar/filtros/tipo/{nombre}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarCabaniasPorTipo(string nombre)
        {
            try
            {
                return Ok(filtros.GetCabaniasPorTipo(nombre));


            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        /// <summary>
        ///  Función que permite listar todas las cabañas por cantidad de personas
        /// </summary>
        /// <param name="cantPersonas">se buscan las cabañas con esa cantidad de personas o más</param>
        /// <returns>retorna lista cabañas por cantidad de Personas</returns>

        [HttpGet("/Cabania/Listar/filtros/Personas/{cantPersonas}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarCabaniasPorCantPersonas(int cantPersonas)
        {
            try
            {
                return Ok(filtros.GetCabaniasPorCantPersonas(cantPersonas));


            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        /// <summary>
        ///  Función listar dados un tipo Cabaña y un monto cabañas un costo diario menor a ese monto, que tengan jacuzzi y estén habilitadas para reserva.
        /// </summary>
        /// <param name="NombreTipo"></param>
        /// <param name="CostoHuesped"></param>
        /// <returns>retorna lista cabañas por tipo Cabaña y un monto</returns>

        [HttpGet("/Cabania/Listar/filtros/TipoMonto/{NombreTipo}/{CostoHuesped}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetCabaniaPorNombreTipoYMonto(string NombreTipo, int CostoHuesped)
        {
            try
            {
                return Ok(filtros.GetCabaniaPorNombreTipoYMonto(NombreTipo, CostoHuesped));


            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }



    }
}
