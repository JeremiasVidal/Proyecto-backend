using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Excepciones;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ApiObl.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class LoginController : ControllerBase
    {
        private IConfiguration configuracion { get; set; }
        private ManejadorJWT ManejadorJWT { get; set; }

        public LoginController(IConfiguration configuration, ILoginCS obtenerUsuario)
        {
            this.ManejadorJWT = new ManejadorJWT(obtenerUsuario);
            this.configuracion = configuration;
        }





        /// <summary>
        /// Funci�n que permite loguearse dentro de la aplicaci�n
        /// </summary>
        /// <param name="usuario">Aqu� recibimos los datos a verificar para decidir si son correctos o no</param>
        /// <returns>retorna token y Usuario</returns>
        [HttpPost("/Login")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Login([FromBody] DTOUsuario usuario)
        {
            try
            {
                DTOUsuario usuarioActual = ManejadorJWT.ObtenerUsuario(usuario);


                var token = ManejadorJWT.GenerarToken(usuario, configuracion);

                return Ok(new
                {
                    Token = token,
                    Usuario = usuario
                });
            }
            catch (InvalidUsuarioException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Ocurri� un error en el servidor");
            }
        }
    }
}






