﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Excepciones;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiObl.Controllers
{       [ApiController]
        [Route("[controller]")]
        [Authorize]
        [ApiConventionType(typeof(DefaultApiConventions))]
    public class MantenimientoController : Controller
    {
        private ICrearMantenimientoCS agregar;
        private IGetMantenimientosEntreFechasCS entreFechas;
        private IGetCabaniaDeMantenimientoCS cabDeMantenimiento;
        private IMantenimientoPorMontoCS montos;

        public MantenimientoController(ICrearMantenimientoCS agregar, IGetMantenimientosEntreFechasCS entreFechas, IGetCabaniaDeMantenimientoCS cabDeMantenimiento, IMantenimientoPorMontoCS montos)
        {
            this.agregar = agregar;
            this.entreFechas = entreFechas;
            this.cabDeMantenimiento = cabDeMantenimiento;
            this.montos = montos;
        }



        /// <summary>
        /// Función utilizada para crear un mantenimiento
        /// </summary>
        /// <param name="mante">Aquí se ingresan los datos requeridos para la creación</param>
        /// <returns>Retorna el mantenimiento creadado</returns>
        [HttpPost("/Mantenimiento/Crear")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Crear([FromBody] DTOMantenimiento mante)
        {
            try
            {
                Uri url = new Uri("https://localhost:7079/Mantenimiento/Crear");

                return Created(url, agregar.CrearMantenimiento(mante));
            }
            catch (InvalidMantenimientoException ex)
            {

                return BadRequest(ex.Message);
            }
        }



        /// /// <summary>
        /// Función utilizada para listar mantenimientos entre fechas de una cabaña
        /// </summary>
        /// <param name="f1"></param>
        /// <param name="f2"></param>
        /// <param name="idHabitacion"></param>
        /// <returns>Retorna lista de mantenimientos entre fechas de una cabaña </returns>
        [HttpGet("/Mantenimiento/Listar/filtro/fechas/{f1}/{f2}/{idHabitacion}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarMantenimientosEntreFechas( DateTime f1, DateTime f2,int idHabitacion)
        {
            return Ok(entreFechas.GetMantenimientosEntreFechas(f1,f2,idHabitacion));
        }





        /// /// <summary>
        /// Función utilizada para obtener la cabania de un mantenimiento 
        /// </summary>
        /// <param name="idHab">Id de habitacion</param>
        /// <returns>Retorna una cabaña </returns>
        [HttpGet("/Mantenimiento/Cabania/{idHab}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarCabaniaDeMantenimiento(int idHab)
        {
            return Ok(cabDeMantenimiento.GetCabaniaDeMantenimiento(idHab));
        }

        /// <summary>
        /// Busca los mantenimientos los cuales contengan la capacidad de personas incluida entre los parametros
        /// </summary>
        /// <param name="m1">Cantidad minima de capacidad de personas</param>
        /// <param name="m2">Cantidad maxima de capacidad de personas</param>
        /// <returns>Retorna la lista de mantenimientos</returns>
        [HttpGet("/Mantenimiento/filtro/monto/{m1}/{m2}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetMantenimientosPorMontos(int m1,int m2)
        {
            return Ok(montos.GetMantenimientosPorMontos(m1,m2));
        }








    }
}
