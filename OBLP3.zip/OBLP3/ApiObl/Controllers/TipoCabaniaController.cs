﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Excepciones;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiObl.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    [ApiConventionType(typeof(DefaultApiConventions))]
    public class TipoCabaniaController : Controller
    {


        private ICreateTipoCabaniaCS agregar;
        private IDeleteTipoCabaniaCS borrar;
        private IEditTipoCabaniaCS editar;
        private IGetTiposCabaniasCS listar;

        public TipoCabaniaController(ICreateTipoCabaniaCS agregar, IDeleteTipoCabaniaCS borrar, IEditTipoCabaniaCS editar, IGetTiposCabaniasCS listar)
        {
            this.agregar = agregar;
            this.borrar = borrar;
            this.editar = editar;
            this.listar = listar;
        }


        /// <summary>
        /// Crea un nuevo Tipo Cabaña y lo agrega a la base de datos
        /// </summary>
        /// <param name="tipo">Valida los datos del tipo cabaña para agregarlo</param>
        /// <returns>retorna el tipo de cabaña creada</returns>
        [HttpPost("/TipoCabania/Crear")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Crear([FromBody] DTOTipoCabania tipo)
        {
            try
            {
                Uri url = new Uri("https://localhost:7079/TipoCabania/Crear");

                return Created(url, agregar.create(tipo));
            }
            catch (InvalidTipoCabaniaException ex)
            {

                return BadRequest(ex.Message);
            }
        }







        /// <summary>
        /// Lista todos los tipos de cabañas
        /// </summary>
        /// <returns>Una lista de tipos de cabañas</returns>
        [HttpGet("/TipoCabania/Listar")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult ListarTipoCabania()
        {
            IEnumerable<DTOTipoCabania> tipocabania = listar.List();
            if (tipocabania.Count() == 0)
            {
                return NotFound();
            }
            return Ok(tipocabania);


        }


        /// <summary>
        /// Elimina un tipo Cabaña
        /// </summary>
        /// <param name="nombre">Manda el nombre tipo cabaña que quiere borrar</param>
        /// <returns>retorna el codigo 200 si se elimina correctamente sino un mensaje de error </returns>
        [HttpDelete("/TipoCabania/Borrar/{nombre}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]

        public IActionResult BorrarTipoCabania(string nombre)
        {


            try
            {
                if (listar.GetPorNombre(nombre) == null)
                {
                    return NotFound(nombre + " No encontrado");
                }
                borrar.DeleteTipoCabania(nombre);
                return Ok("Borrado con éxito");


            }
            catch (InvalidTipoCabaniaException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Se utiliza para editar la descripción y el costo por huésped un tipo cabaña
        /// </summary>
        /// <param name="tipo">Ingresando el nombre en el body para buscarlo y los datos de la descripcion y el costo huesped a editar se verificarán y se editará</param>
        /// <returns>Si se edita correctamente muestra un mensaje.</returns>
        [HttpPut("/TipoCabania/Editar")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]

        public IActionResult EditarTipoCabania([FromBody] DTOTipoCabania tipo)
        {
            try
            {
                if (listar.GetPorNombre(tipo.Nombre) == null)
                {
                    return NotFound("No encontrado");
                }
                else
                {
                    editar.Edit(tipo);
                    return Ok("Editado con éxito");
                }

            }
            catch (InvalidTipoCabaniaException e)
            {
                return BadRequest(e.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }


        }

        /// <summary>
        ///  Función que permite listar todas los Tipo cabañas por nombre
        /// </summary>
        /// <param name="nombre">se buscan los Tipo cabañas con ese nombre</param>
        /// <returns>retorna  Tipo cabañas por nombre</returns>

        [HttpGet("/TipoCabania/Listar/nombre/{nombre}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult TipoCabaniaPorNombre(string nombre)
        {
            try
            {
                return Ok(listar.GetPorNombre(nombre));
            }
            catch (InvalidTipoCabaniaException ex)
            {

                return BadRequest(ex.Message);
            }

        }
    }
}