﻿using LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOs
{
    public class DTOMantenimiento
    {

        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public string Descripcion { get; set; }
        public int Costo { get; set; }
        public string Nombre { get; set; }
        public int IdCaba { get; set; }
        public DTOCabania Cabania { get; set; }

        public DTOMantenimiento()
        {
            
        }
        public DTOMantenimiento(Mantenimiento Mantenimiento)
        {
            this.Id = Mantenimiento.Id;
            this.Fecha = Mantenimiento.Fecha;
            this.Descripcion = Mantenimiento.descripcionMan.descripcionMan;
            this.Costo = Mantenimiento.Costo.costoMan;
            this.Nombre = Mantenimiento.Nombre;
            this.Cabania = new DTOCabania(Mantenimiento.Cabania);
        }

    }
}
