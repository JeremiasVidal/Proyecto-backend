﻿using LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOs
{
    public class DTOCabania
    {
        
        public int IdHabitacion { get; set; }
        public string Nombre { get; set; }
       public string NombreTipo { get; set; }
        public DTOTipoCabania Tipo { get; set; }

        public string Descripcion { get; set; }
        public bool Jacuzzi { get; set; }
        public bool Habilitada { get; set; }
        public int CantPersonas { get; set; }
        public string? Foto { get; set; }



        public DTOCabania()
        {
            
        }
        public DTOCabania(Cabania cab)
        {
            IdHabitacion = cab.IdHabitacion;
            Nombre = cab.Nombre;
            NombreTipo= cab.NombreTipo;
            Tipo = new DTOTipoCabania(cab.Tipo);
            Descripcion = cab.Descripcion.Descripcion;
            Jacuzzi = cab.Jacuzzi;
            Habilitada = cab.Habilitada;
            CantPersonas = cab.CantPersonas;
            Foto = cab.Foto;
        }
    }
}
