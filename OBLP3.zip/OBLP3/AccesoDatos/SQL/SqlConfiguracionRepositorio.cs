﻿using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos.SQL
{
    public class SqlConfiguracionRepositorio : IConfiguracionRepositorio
    {
        private OBLContexto cont;

        public SqlConfiguracionRepositorio()
        {
            cont = new OBLContexto();
        }

        public void Create(Configuracion obj)
        {
            throw new NotImplementedException();
        }

     
        public void Delete(Configuracion obj)
        {
            throw new NotImplementedException();
        }

        public int LimiteInferior(string atributo)
        {
            Configuracion config = cont.configuracion.Where(config => config.Atributo == atributo).FirstOrDefault();
            if (config == null)
            {
                throw new InvalidConfiguracionException("Atributo inexistente");
            }
            return config.LimiteInferior;   
        }

        public int LimiteSuperior(string atributo)
        {
            Configuracion config = cont.configuracion.Where(con => con.Atributo == atributo).FirstOrDefault();
            if (config == null)
            {
                 throw new InvalidConfiguracionException("Atributo inexistente");
            }
            return config.LimiteSuperior;
           
        }

        public IEnumerable<Configuracion> List()
        {
            throw new NotImplementedException();
        }
    }
}
