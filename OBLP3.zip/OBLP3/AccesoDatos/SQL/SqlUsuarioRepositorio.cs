﻿using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos.SQL
{
    public class SqlUsuarioRepositorio : IUsuarioRepositorio
    {
        private OBLContexto cont;
        private IConfiguracionRepositorio conf;
        public SqlUsuarioRepositorio(IConfiguracionRepositorio conf)
        {
            cont = new OBLContexto();
            this.conf = conf;
        }
        public void Create(Usuario obj)
        {
            try
            {
                if (GetPorUsuario(obj.Email)==null)
                {
                  obj.Validar(conf);
                cont.usuarios.Add(obj);
                cont.SaveChanges();
                throw new InvalidUsuarioException("Usuario creado con exito");
                }
                else
                {
                    throw new InvalidUsuarioException("Usuario ya existente");

                }

            }
            catch (InvalidUsuarioException ce)
            {
                throw new InvalidUsuarioException(ce.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(Usuario obj)
        {
            throw new NotImplementedException();
        }


        public Usuario GetPorUsuario(string user)
        {
            return cont.usuarios.Where(usu => usu.Email == user).FirstOrDefault();
        }

        public IEnumerable<Usuario> List()
        {
            throw new NotImplementedException();
        }

       
    }
}
