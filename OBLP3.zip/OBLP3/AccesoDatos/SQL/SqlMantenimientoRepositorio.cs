﻿using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos.SQL
{
    public class SqlMantenimientoRepositorio : IMantenimientoRepositorio
    {
        private OBLContexto cont;
        private IConfiguracionRepositorio conf;
        public SqlMantenimientoRepositorio(IConfiguracionRepositorio con)
        {
            cont = new OBLContexto();
            conf = con;
        }
        
        public void Create(Mantenimiento obj)
        {
            int cant = 1;
            try
            {
               cant = cont.mantenimientos.Where(man=>man.Fecha.Date== obj.Fecha.Date && man.IdCaba==obj.IdCaba).ToList().Count;
                if(cant <3 ) {
                    obj.Validar(conf);
                    cont.mantenimientos.Add(obj);
                    cont.SaveChanges();
                }
                else
                {
                    throw new InvalidMantenimientoException("Ya se han realizado los 3 mantenimientos disponibles en el dia");
                }
               
            }
            catch(InvalidMantenimientoException me) {
                throw new InvalidMantenimientoException(me.Message);
            }
            catch (Exception ex) {
                throw new Exception(ex.Message);            
            }
        }

        public void Delete(Mantenimiento obj)
        {
            try
            {
                if (obj != null)
                {
                    if (cont.mantenimientos.Where(man => man.IdCaba == obj.IdCaba && man.Fecha==obj.Fecha).FirstOrDefault() != null)
                    {
                        cont.mantenimientos.Remove(obj);
                        cont.SaveChanges();
                        throw new InvalidMantenimientoException("Eliminado correctamente");
                    }
                    else
                    {
                        throw new InvalidMantenimientoException("No existe esa mantenimiento");
                    }
                }
                else
                {
                    throw new InvalidMantenimientoException("No puede ingresar un mantenimiento vacio");
                }

            }
            catch (InvalidMantenimientoException ce)
            {
                throw new InvalidMantenimientoException(ce.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Cabania GetCabaniaDeMantenimiento(int id)
        {
            return cont.cabañas.Where(cab => cab.IdHabitacion == id).Include("Tipo").FirstOrDefault();
        }


        public IEnumerable<Mantenimiento> GetMantenimientosPorMontos(int m1, int m2)
        {
            if (m2 > m1)
            {
                int aux = m1;
                m1 = m2;
                m2 = aux;
            }

            var mantenimientosQuery = cont.mantenimientos
                .Where(man => man.Cabania.CantPersonas <= m1 && man.Cabania.CantPersonas >= m2).Include(man => man.Cabania).ThenInclude(cab => cab.Tipo)
                .AsEnumerable()
                .GroupBy(man => man.Nombre)
                .SelectMany(group => group)
                .ToList();

            return mantenimientosQuery;
        }

        public Mantenimiento GetPorId(int id)
        {
            return cont.mantenimientos.Where(man => man.Id == id).Include(man=>man.Cabania).ThenInclude(cab=>cab.Tipo).FirstOrDefault();
        }

        public IEnumerable<Mantenimiento> List()
        {
           return cont.mantenimientos.Include("Cabania").ToList();
        }

        public IEnumerable<Mantenimiento> ListEntreFechas(DateTime f1, DateTime f2,int IdHabitacion)
        {
            if (f2 > f1)
            {
                DateTime aux= f1;
                f1 = f2;
                f2 = aux;
            }
           
            List<Mantenimiento> ret= cont.mantenimientos.Where(man => man.Fecha >= f2 && man.Fecha <= f1 && man.IdCaba==IdHabitacion ).OrderByDescending(man => man.Costo.costoMan).Include(man => man.Cabania).ThenInclude(cab => cab.Tipo).ToList();
            return ret;
        }
    }
}
