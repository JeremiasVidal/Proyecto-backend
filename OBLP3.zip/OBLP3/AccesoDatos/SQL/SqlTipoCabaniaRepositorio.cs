﻿using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos.SQL
{
    public class SqlTipoCabaniaRepositorio : ITipoCabaniaRepositorio
    {
        private OBLContexto cont;
        private IConfiguracionRepositorio conf;
        public SqlTipoCabaniaRepositorio(IConfiguracionRepositorio conf)
        {
            cont = new OBLContexto();
            this.conf = conf;
        }
        public void Create(TipoCabania obj)
        {
            try
            {
                if(GetPorNombre(obj.Nombre) == null)
                {
                obj.Validar(conf);
                cont.tipoCabanias.Add(obj);
                cont.SaveChanges();
                }
                else{
                    throw new InvalidTipoCabaniaException("Ya existe");

                }


            }
            catch (InvalidTipoCabaniaException ce)
            {
                throw new InvalidTipoCabaniaException(ce.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(TipoCabania obj)
        {
            try
            {
                if (obj != null)
                {
                    TipoCabania obj2 = GetPorNombre(obj.Nombre);
                    if (obj2 != null)
                    {


                        Cabania uso = cont.cabañas.Where(cab => cab.Tipo == obj).FirstOrDefault();
                        if (uso == null)
                        {
                          
                           cont.tipoCabanias.Remove(obj2);

                            cont.SaveChanges();

                        }

                        else
                        {
                            throw new InvalidTipoCabaniaException("Esta en uso");
                        }
                    }
                    else
                    {
                        throw new InvalidTipoCabaniaException("El tipo de cabaña no existe");
                    }

                }
                else
                {
                    throw new InvalidTipoCabaniaException("El tipo de cabaña no puede ser vacío");
                }
            }
            catch (InvalidTipoCabaniaException te)
            {
                throw new InvalidTipoCabaniaException(te.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void Edit(string Nombre, string desc, CostoHuesped costoHuesped)
        {
            try
            {
                TipoCabania obj = GetPorNombre(Nombre);
                if (obj != null)
                {
                    obj.Descripcion = desc;
                    obj.CostoHuesped = costoHuesped;
                    obj.Validar(new SqlConfiguracionRepositorio());
                    cont.SaveChanges();

                }
                else
                {
                    throw new InvalidTipoCabaniaException("No existe el tipo de cabaña");
                }


            }
            catch (InvalidCabaniaException ce)
            {
                throw new InvalidCabaniaException(ce.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        public TipoCabania GetPorNombre(string nombre)
        {
            return cont.tipoCabanias.Where(tipo => tipo.Nombre == nombre).FirstOrDefault();
        }

        public IEnumerable<TipoCabania> List()
        {
            return cont.tipoCabanias.ToList();
        }





    }
}
