﻿using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos.SQL
{
    public class SqlCabaniaRepositorio : ICabaniaRepositorio
    {
        private OBLContexto cont;
        private IConfiguracionRepositorio conf;
        public SqlCabaniaRepositorio(IConfiguracionRepositorio con)
        {
            cont = new OBLContexto();
            conf= con;
        }
        public void Create(Cabania obj)
        {
            try
            {
                if(GetPorNombre(obj.Nombre) == null)
                {
                    obj.Validar(conf);
                    cont.cabañas.Add(obj);
                    cont.SaveChanges();
                }
                else
                {
                    throw new InvalidCabaniaException("La cabaña ya existe");
                }
               
            }
            catch (InvalidCabaniaException ce)
            {
                throw new InvalidCabaniaException(ce.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                Console.WriteLine("Excepción interna: " + ex.InnerException?.Message);
                throw new Exception(ex.Message);
            }
        }

        public void Delete(Cabania obj)
        {
            try
            {
                if (obj != null)
                {
                    if (cont.cabañas.Where(cab => cab.IdHabitacion == obj.IdHabitacion).FirstOrDefault() != null)
                    {
                        cont.cabañas.Remove(obj);
                        cont.SaveChanges();
                        throw new InvalidCabaniaException("Eliminado correctamente");
                    }
                    else
                    {
                        throw new InvalidCabaniaException("No existe esa cabaña");
                    }
                }
                else
                {
                    throw new InvalidCabaniaException("No puede ingresar una cabaña vacía");
                }

            }
            catch (InvalidCabaniaException ce)
            {
                throw new InvalidCabaniaException(ce.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public IEnumerable<Cabania> GetCabaniaPorNombreTipoYMonto(string nombre, int monto)
        {
            return cont.cabañas.Where(cab => cab.NombreTipo == nombre && cab.Tipo.CostoHuesped.CostoPorHuesped * cab.CantPersonas < monto && cab.Jacuzzi && cab.Habilitada).Include("Tipo").ToList();
        }
        public IEnumerable<Cabania> GetCabaniasHabilitadas()
        {
            return cont.cabañas.Where(ca=>ca.Habilitada==true).Include("Tipo").ToList();
        }

        public IEnumerable<Cabania> GetCabaniasPorCantPersonas(int cant)
        {
            return cont.cabañas.Where(ca => ca.CantPersonas >= cant).Include("Tipo").ToList();
        }

        public IEnumerable<Cabania> GetCabaniasPorNombre(string nombre)
        {
            return cont.cabañas.Where(ca => ca.Nombre.Contains(nombre)).Include("Tipo").ToList();
        }

        public IEnumerable<Cabania> GetCabaniasPorTipo(string Nombre)
        {
            return cont.cabañas.Where(ca => ca.Tipo.Nombre == Nombre).Include("Tipo").ToList();
        }

        public Cabania GetPorNombre(string nombre)
        {
            return cont.cabañas.Where(ca => ca.Nombre == nombre).Include("Tipo").FirstOrDefault();
        }

        

        public IEnumerable<Cabania> List()
        {
            return cont.cabañas.Include("Tipo").ToList();
        }


    }
}
