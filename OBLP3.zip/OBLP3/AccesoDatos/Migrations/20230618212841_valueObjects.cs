﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AccesoDatos.Migrations
{
    /// <inheritdoc />
    public partial class valueObjects : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Descripcion",
                table: "mantenimientos");

            migrationBuilder.DropColumn(
                name: "Descripcion",
                table: "cabañas");

            migrationBuilder.RenameColumn(
                name: "CostoHuesped",
                table: "tipoCabanias",
                newName: "CostoHuesped_CostoPorHuesped");

            migrationBuilder.RenameColumn(
                name: "Costo",
                table: "mantenimientos",
                newName: "Costo_costoMan");

            migrationBuilder.AlterColumn<string>(
                name: "Descripcion",
                table: "tipoCabanias",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200);

            migrationBuilder.AddColumn<string>(
                name: "Descripcion_descripcionMan",
                table: "mantenimientos",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Descripcion_descripcionMan",
                table: "mantenimientos");

            migrationBuilder.RenameColumn(
                name: "CostoHuesped_CostoPorHuesped",
                table: "tipoCabanias",
                newName: "CostoHuesped");

            migrationBuilder.RenameColumn(
                name: "Costo_costoMan",
                table: "mantenimientos",
                newName: "Costo");

            migrationBuilder.AlterColumn<string>(
                name: "Descripcion",
                table: "tipoCabanias",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "Descripcion",
                table: "mantenimientos",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Descripcion",
                table: "cabañas",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
