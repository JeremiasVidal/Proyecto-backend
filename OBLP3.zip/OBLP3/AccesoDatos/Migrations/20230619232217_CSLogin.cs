﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AccesoDatos.Migrations
{
    /// <inheritdoc />
    public partial class CSLogin : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Borrado",
                table: "tipoCabanias");

            migrationBuilder.RenameColumn(
                name: "Descripcion_descripcionMan",
                table: "mantenimientos",
                newName: "descripcionMan_descripcionMan");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "descripcionMan_descripcionMan",
                table: "mantenimientos",
                newName: "Descripcion_descripcionMan");

        
        }
    }
}
