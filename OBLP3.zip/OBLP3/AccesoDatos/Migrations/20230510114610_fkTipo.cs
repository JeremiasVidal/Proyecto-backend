﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AccesoDatos.Migrations
{
    /// <inheritdoc />
    public partial class fkTipo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_cabañas_tipoCabanias_TipoNombre",
                table: "cabañas");

            migrationBuilder.RenameColumn(
                name: "TipoNombre",
                table: "cabañas",
                newName: "NombreTipo");

            migrationBuilder.RenameIndex(
                name: "IX_cabañas_TipoNombre",
                table: "cabañas",
                newName: "IX_cabañas_NombreTipo");

            migrationBuilder.AddForeignKey(
                name: "FK_cabañas_tipoCabanias_NombreTipo",
                table: "cabañas",
                column: "NombreTipo",
                principalTable: "tipoCabanias",
                principalColumn: "Nombre",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_cabañas_tipoCabanias_NombreTipo",
                table: "cabañas");

            migrationBuilder.RenameColumn(
                name: "NombreTipo",
                table: "cabañas",
                newName: "TipoNombre");

            migrationBuilder.RenameIndex(
                name: "IX_cabañas_NombreTipo",
                table: "cabañas",
                newName: "IX_cabañas_TipoNombre");

            migrationBuilder.AddForeignKey(
                name: "FK_cabañas_tipoCabanias_TipoNombre",
                table: "cabañas",
                column: "TipoNombre",
                principalTable: "tipoCabanias",
                principalColumn: "Nombre",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
