﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AccesoDatos.Migrations
{
    /// <inheritdoc />
    public partial class correcciones : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_mantenimientos",
                table: "mantenimientos");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "mantenimientos",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_mantenimientos",
                table: "mantenimientos",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_mantenimientos",
                table: "mantenimientos");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "mantenimientos");

            migrationBuilder.AddPrimaryKey(
                name: "PK_mantenimientos",
                table: "mantenimientos",
                columns: new[] { "Fecha", "IdCaba" });
        }
    }
}
