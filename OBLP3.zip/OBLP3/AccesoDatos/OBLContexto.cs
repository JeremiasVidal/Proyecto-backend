﻿using LogicaNegocio.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos
{
    public class OBLContexto:DbContext
    {

        public DbSet<Cabania> cabañas { get; set; }
        public DbSet<Mantenimiento> mantenimientos { get; set; }
        public DbSet<TipoCabania> tipoCabanias { get; set; }
        public DbSet<Usuario> usuarios { get; set; }
        public DbSet<Configuracion> configuracion { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string cadenaConexion =
                @"SERVER=(localdb)\MSsqlLocaldb;
                DATABASE=ObligatorioP32023S3;
                INTEGRATED SECURITY=TRUE;
                ENCRYPT=False"; 
            optionsBuilder.UseSqlServer(cadenaConexion)
                .EnableDetailedErrors();
        }
    }
}
