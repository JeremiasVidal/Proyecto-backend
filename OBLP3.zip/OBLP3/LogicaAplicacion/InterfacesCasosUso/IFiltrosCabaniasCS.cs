﻿using DTOs;
using LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.InterfacesCasosUso
{
    public interface IFiltrosCabaniasCS
    {
        public IEnumerable<DTOCabania> List();
        public IEnumerable<DTOCabania> GetCabaniasPorNombre(string nombre);
        public IEnumerable<DTOCabania> GetCabaniasPorTipo(string nombre);
        public IEnumerable<DTOCabania> GetCabaniasPorCantPersonas(int cant);
        public IEnumerable<DTOCabania> GetCabaniasHabilitadas();

        public IEnumerable<DTOCabania> GetCabaniaPorNombreTipoYMonto(string nombre, int monto);
       
    }
}
