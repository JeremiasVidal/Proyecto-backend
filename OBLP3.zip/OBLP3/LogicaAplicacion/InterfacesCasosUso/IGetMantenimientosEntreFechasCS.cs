﻿using DTOs;
using LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.InterfacesCasosUso
{
    public interface IGetMantenimientosEntreFechasCS
    {
        public IEnumerable<DTOMantenimiento> GetMantenimientosEntreFechas(DateTime f1, DateTime f2, int IdHabitacion);
    }
}
