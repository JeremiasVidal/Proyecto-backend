﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class GetTiposCabaniasCS : IGetTiposCabaniasCS
    {
        private ITipoCabaniaRepositorio rep;
        public GetTiposCabaniasCS(ITipoCabaniaRepositorio re)
        {
            this.rep = re;
        }

        public DTOTipoCabania GetPorNombre(string nombre)
        {
            try
            {
                if (rep.GetPorNombre(nombre) != null)
                {
                DTOTipoCabania ret = new DTOTipoCabania(rep.GetPorNombre(nombre));

                return ret;
                }
                else
                {
                    throw new InvalidTipoCabaniaException("No existe tipo cabania");

                }

            }
            catch (InvalidTipoCabaniaException ex )
            {
                throw new InvalidTipoCabaniaException(ex.Message);
            }
        }

        public IEnumerable<DTOTipoCabania> List()
        {
            return rep.List().Select(x => new DTOTipoCabania(x));
        }
    }
}




