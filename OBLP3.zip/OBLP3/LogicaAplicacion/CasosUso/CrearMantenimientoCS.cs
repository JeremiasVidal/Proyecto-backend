﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class CrearMantenimientoCS : ICrearMantenimientoCS
    {
        public IMantenimientoRepositorio rep { get; set; }
        public CrearMantenimientoCS(IMantenimientoRepositorio re)
        {
            this.rep = re;
        }
        public DTOMantenimiento CrearMantenimiento(DTOMantenimiento mantenimiento)
        {

         Mantenimiento ret=  new Mantenimiento(mantenimiento.Fecha,new DescripcionMantenimiento(mantenimiento.Descripcion),new Costo(mantenimiento.Costo),mantenimiento.Nombre,mantenimiento.IdCaba);
         
               rep.Create(ret);
             return new DTOMantenimiento(rep.GetPorId(ret.Id));
           

        }

    }
}

