﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class EditTipoCabaniaCS : IEditTipoCabaniaCS
    {
        private ITipoCabaniaRepositorio rep;
        public EditTipoCabaniaCS(ITipoCabaniaRepositorio re)
        {
            this.rep = re;
        }
        public void Edit(DTOTipoCabania tipCab)
        {
            try
            {
                rep.Edit(tipCab.Nombre, tipCab.Descripcion, new CostoHuesped(tipCab.CostoHuesped));
            }
            catch (InvalidTipoCabaniaException ex)
            {
                throw new InvalidTipoCabaniaException(ex.Message);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);

            }

        }
    }
}
