﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class MantenimientosPorMontoCS: IMantenimientoPorMontoCS
    {
        public IMantenimientoRepositorio rep { get; set; }
        public MantenimientosPorMontoCS(IMantenimientoRepositorio re)
        {
            this.rep = re;
        }

        public IEnumerable<DTOMantenimiento> GetMantenimientosPorMontos(int m1, int m2)
        {
            return rep.GetMantenimientosPorMontos(m1, m2).Select(man => new DTOMantenimiento(man));
        }
    }
}
