﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class LoginCS : ILoginCS
    {
        public IUsuarioRepositorio rep { get; set; }
        public LoginCS(IUsuarioRepositorio re)
        {
            this.rep = re;
        }
        public DTOUsuario Login(string username, string password)
        {

            DTOUsuario retorno = new DTOUsuario();
           Usuario u= rep.GetPorUsuario(username);
            if (u == null)
            {
               throw new InvalidUsuarioException("Usuario no existente");
            }
            else
            {
                if(u.Password == password)
                {
                    retorno.Email = u.Email;
                    retorno.Password = u.Password;
                    return retorno;
                }
                else
                {
                    throw new InvalidUsuarioException("Contraseña incorrecta");

                }
          

            }


        }

    }
}

