﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class FiltrosCabaniasCS : IFiltrosCabaniasCS
    {
        private ICabaniaRepositorio rep;
        public FiltrosCabaniasCS(ICabaniaRepositorio re)
        {
            this.rep = re;
        }
        public IEnumerable<DTOCabania> GetCabaniasHabilitadas()
        {

            return rep.GetCabaniasHabilitadas().Select(x=>new DTOCabania(x)); 
        }

        public IEnumerable<DTOCabania> GetCabaniasPorCantPersonas(int cant)
        {
           return rep.GetCabaniasPorCantPersonas(cant).Select(x => new DTOCabania(x)); 
        }






        public IEnumerable<DTOCabania> GetCabaniasPorNombre(string nombre)
        {
            try
            {
                if (rep.GetCabaniasPorNombre(nombre) != null)
                {
                    return rep.GetCabaniasPorNombre(nombre).Select(x => new DTOCabania(x));
                }
                else
                {
                    throw new InvalidCabaniaException("No existen cabanias");

                }

            }
            catch (InvalidCabaniaException ex)
            {
                throw new InvalidCabaniaException(ex.Message);
            }
        }

       








        public IEnumerable<DTOCabania> GetCabaniasPorTipo(string nombre)
        {
            return rep.GetCabaniasPorTipo(nombre).Select(x => new DTOCabania(x));
        }

      

        public IEnumerable<DTOCabania> List()
        {
            return rep.List().Select(x => new DTOCabania(x));

        }
        public IEnumerable<DTOCabania> GetCabaniaPorNombreTipoYMonto(string nombre, int monto)
        {
            return rep.GetCabaniaPorNombreTipoYMonto(nombre, monto).Select(x => new DTOCabania(x));
        }
    }
}
