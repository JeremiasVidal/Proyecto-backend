﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class DeleteTipoCabaniaCS : IDeleteTipoCabaniaCS
    {
        public ITipoCabaniaRepositorio rep { get; set; }
        public DeleteTipoCabaniaCS(ITipoCabaniaRepositorio re)
        {
            this.rep = re;
        }

        public void DeleteTipoCabania(string nombre)
        {
            TipoCabania tipo = rep.GetPorNombre(nombre);
            rep.Delete(tipo);
        }
    }
}




