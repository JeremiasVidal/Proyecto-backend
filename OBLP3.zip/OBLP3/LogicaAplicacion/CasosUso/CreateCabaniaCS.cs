﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class CreateCabaniaCS : ICreateCabaniaCS
    {
        private ICabaniaRepositorio rep;
        public CreateCabaniaCS(ICabaniaRepositorio re)
        {
            this.rep = re;
        }
        public DTOCabania Create(DTOCabania cab)
        {

            Cabania crear= new Cabania(cab.Nombre,cab.NombreTipo,new DescripcionCaba(cab.Descripcion),cab.Jacuzzi,cab.Habilitada,cab.CantPersonas,cab.Foto);
          
            rep.Create(crear);
            return new DTOCabania(rep.GetPorNombre(cab.Nombre));
        }
    }




}

