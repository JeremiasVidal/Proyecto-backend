﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class CreateTipoCabaniaCS : ICreateTipoCabaniaCS
    {
        public ITipoCabaniaRepositorio rep { get; set; }
        public CreateTipoCabaniaCS(ITipoCabaniaRepositorio re)
        {
            this.rep = re;
        }

        public DTOTipoCabania create(DTOTipoCabania tipoCab)
        {
            TipoCabania agregar = new TipoCabania();
            agregar.Nombre = tipoCab.Nombre; 
            agregar.Descripcion = tipoCab.Descripcion;
            agregar.CostoHuesped = new CostoHuesped(tipoCab.CostoHuesped);
            rep.Create(agregar);

            return new DTOTipoCabania(rep.GetPorNombre(tipoCab.Nombre));


        }
    }
}
