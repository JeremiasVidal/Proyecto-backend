﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class GetMantenimientosEntreFechasCS : IGetMantenimientosEntreFechasCS
    {
        private IMantenimientoRepositorio rep;
        public GetMantenimientosEntreFechasCS(IMantenimientoRepositorio re)
        {
            this.rep = re;
        }
        public IEnumerable<DTOMantenimiento> GetMantenimientosEntreFechas(DateTime f1, DateTime f2, int IdHabitacion)
        {
           return rep.ListEntreFechas(f1,f2,IdHabitacion).Select(x => new DTOMantenimiento(x)); 
        }
    }
}
