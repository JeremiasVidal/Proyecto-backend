﻿using DTOs;
using LogicaAplicacion.InterfacesCasosUso;
using LogicaNegocio.Entidades;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaAplicacion.CasosUso
{
    public class GetCabaniaDeMantenimientoCS : IGetCabaniaDeMantenimientoCS
    {
        private IMantenimientoRepositorio rep { get; set;}
        public GetCabaniaDeMantenimientoCS(IMantenimientoRepositorio re)
        {
            this.rep = re;
        }

        public DTOCabania GetCabaniaDeMantenimiento(int idHab)
        {
            DTOCabania ret =new DTOCabania(rep.GetCabaniaDeMantenimiento(idHab));
            return ret;
        }
    }
}