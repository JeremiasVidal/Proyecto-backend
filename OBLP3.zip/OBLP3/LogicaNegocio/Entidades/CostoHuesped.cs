﻿using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Entidades
{
    [Owned]
    public class CostoHuesped:IValidar
    {
        public int CostoPorHuesped { get; set; }

        public CostoHuesped(int costoPorHuesped)
        {
            CostoPorHuesped = costoPorHuesped;
        }

        public void Validar(IConfiguracionRepositorio configuracion)
        {
            if (CostoPorHuesped < 0)
            {
                throw new InvalidTipoCabaniaException("El costo por huésped no puede ser negativo.");
            }
        }
    }
}
