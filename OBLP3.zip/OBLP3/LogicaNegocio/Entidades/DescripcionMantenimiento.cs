﻿using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Entidades
{
    [Owned]

    public class DescripcionMantenimiento : IValidar
    {
        public string descripcionMan { get; set; }

        public DescripcionMantenimiento(string descripcionMan)
        {
            this.descripcionMan = descripcionMan;
        }
     
        public void Validar(IConfiguracionRepositorio configuracion)
        {
            if (string.IsNullOrEmpty(descripcionMan))
            {
                throw new InvalidMantenimientoException("La descripción del mantenimiento no puede estar vacío.");
            }

            if (descripcionMan.Length > configuracion.LimiteSuperior("Descripcion") || descripcionMan.Length < configuracion.LimiteInferior("Descripcion"))
            {
                throw new InvalidMantenimientoException("La longitud de la descripción debe estar entre 10 y 500.");
            }
        }
  
    }
}
