﻿using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicaNegocio.Excepciones;

namespace LogicaNegocio.Entidades
{
    
    public class TipoCabania : IValidar
    {
        [Key] 
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public CostoHuesped CostoHuesped { get; set; }
        

        public TipoCabania()
        {
            
        }
        public TipoCabania(string nombre, string descripcion, CostoHuesped costoHuesped)
        {
            this.Nombre = nombre;
            this.Descripcion = descripcion;
            this.CostoHuesped = costoHuesped;
            
        }

        public void Validar(IConfiguracionRepositorio configuracion)
        {


            if (string.IsNullOrEmpty(Nombre) || string.IsNullOrEmpty(Descripcion))
            {
                throw new InvalidTipoCabaniaException("El nombre y la descripción de la cabaña no pueden estar vacíos.");
            }

            if (Descripcion.Length > configuracion.LimiteSuperior("DescripcionTipo") || Descripcion.Length < configuracion.LimiteInferior("DescripcionTipo"))
            {
                throw new InvalidTipoCabaniaException("La longitud de la descripción debe estar entre 10 y 200.");
            }
           this.CostoHuesped.Validar(configuracion);
            if (Nombre[0]==' ' || Nombre[Nombre.Length-1]==' ')
            {
                throw new InvalidTipoCabaniaException("El nombre no puede tener espacios en blanco al inicio o al final.");
            }
            
            foreach (char c in Nombre)
            {
                if (!Char.IsLetter(c) && c !=' ')
                {
                   
                    throw new InvalidTipoCabaniaException("Los caracteres deben ser alfabeticos."); ;
                }
               
            }
           



        }
        
    }
}
