﻿using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Entidades
{
    public class Usuario : IValidar
    {
        [Key]
        public string Email { get; set; }
        public string Password { get; set; }

        public Usuario(string email, string password)
        {
            Email = email;
            Password = password;
        }

        public Usuario()
        {

        }

        public void Validar(IConfiguracionRepositorio c)
        {
            if (String.IsNullOrEmpty(Email))
            {
                throw new InvalidUsuarioException("Email no puede estar vacío.");
            }
            if (String.IsNullOrEmpty(Password))
            {
                throw new InvalidUsuarioException("Debe contener un password.");
            }
            if (!Email.Contains('@') || Email[0] == '@' || Email[^1] == '@')//VALIDA QUE @ EXISTA, QUE NO ESTÉ AL INICIO NI AL FINAL.
            {
                throw new InvalidUsuarioException("El email debe contener una arroba y no debe estar en el primera ni ultimo caracter");
            }
            if (Password.Length < 6)//CONTRASEÑA QUE CONTENGA AL MENOS 6 CARACTERES
            {
                throw new InvalidUsuarioException("La contraseña debe contener al menos 6 caracteres.");
            }
            if (Password == Password.ToLower() || Password == Password.ToUpper())
            {
                throw new InvalidUsuarioException("La contraseña debe tener al menos una mayúscula y una minúscula");
            }
            if (!Password.Contains('0') || !Password.Contains('1') || !Password.Contains('2') || !Password.Contains('3') || !Password.Contains('4') || !Password.Contains('5') || !Password.Contains('6') || !Password.Contains('7') || !Password.Contains('8') || !Password.Contains('9'))
            {
                throw new InvalidUsuarioException("La contraseña debe tener al menos un digito");
            }
        }
    }
}

