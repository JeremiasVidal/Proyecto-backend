﻿using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Entidades
{
    [Owned]
    
    public class Costo:IValidar
    {
        public int costoMan { get;set; }

        public Costo(int costoMan)
        {
            this.costoMan = costoMan;
        }

        public void Validar(IConfiguracionRepositorio configuracion)
        {
            if (costoMan < 0)
            {
                throw new InvalidMantenimientoException("El costo por mantenimiento no puede ser negativo.");
            }
        }
    }
}
