﻿using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicaNegocio.Excepciones;
using Microsoft.IdentityModel.Tokens;

namespace LogicaNegocio.Entidades
{
    [Index(nameof(Nombre), IsUnique = true)]
    public class Cabania : IValidar
    {
        public static int UltimoIdHabitacion { get; set; }
        [Key]
        public int IdHabitacion { get; set; }
        [Required]
        public string Nombre { get; set; }
        [ForeignKey(nameof(Tipo))] public string NombreTipo { get; set; }
        public TipoCabania Tipo { get; set; }
     
        public DescripcionCaba Descripcion { get; set; }
        public bool Jacuzzi { get; set; }
        public bool Habilitada { get; set; }
        public int CantPersonas { get; set; }
        public string? Foto { get; set; }

        public Cabania()
        {
         
        }
        public Cabania(string nombre, string Nombretipo, DescripcionCaba descripcion, bool jacuzzi, bool habilitada, int cantPersonas, string? foto)
        {
            IdHabitacion = UltimoIdHabitacion;
            Nombre = nombre;
            NombreTipo = Nombretipo;
            Descripcion = descripcion;
            Jacuzzi = jacuzzi;
            Habilitada = habilitada;
            CantPersonas = cantPersonas;
            Foto = foto;
        }

        public void Validar(IConfiguracionRepositorio configuracion)
        {

          this.Descripcion.Validar(configuracion);
            if (string.IsNullOrEmpty(Nombre))
            {
                throw new InvalidCabaniaException("El nombre de la cabaña no puede estar vacío.");
            }

            if (CantPersonas < 0)
            {
                throw new InvalidCabaniaException("La cantidada de personas no puede ser negativa.");
            }
            foreach (char c in Nombre)
            {
                if (!Char.IsLetter(c))
                {
                    throw new InvalidCabaniaException("Los caracteres deben ser alfabeticos."); ;
                }

            }
            if (Nombre[0] == ' ' || Nombre[Nombre.Length - 1] == ' ')
            {
                throw new InvalidCabaniaException("El nombre no puede tener espacios en blanco al inicio o al final.");
            }
            if (string.IsNullOrEmpty(NombreTipo))
            {
                throw new InvalidMantenimientoException("El tipo de cabaña no puede ser vacío.");
            }
            



        }
    }
}
