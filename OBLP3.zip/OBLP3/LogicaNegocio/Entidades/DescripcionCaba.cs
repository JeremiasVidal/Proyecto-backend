﻿using LogicaNegocio.Excepciones;
using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace LogicaNegocio.Entidades
{
    [Owned]
    public class DescripcionCaba:IValidar
    {
       public string Descripcion { get; set; }

        public DescripcionCaba(string descripcion)
        {
            Descripcion = descripcion;
        }

        public void Validar(IConfiguracionRepositorio configuracion)
        {
            if (string.IsNullOrEmpty(Descripcion))
            {
                throw new InvalidCabaniaException("La descripción de la cabaña no puede estar vacío.");
            }

            if (Descripcion.Length > configuracion.LimiteSuperior("Descripcion") || Descripcion.Length < configuracion.LimiteInferior("Descripcion"))
            {
                throw new InvalidCabaniaException("La longitud de la descripción debe estar entre 10 y 500.");
            }
        }
       
    }
}
