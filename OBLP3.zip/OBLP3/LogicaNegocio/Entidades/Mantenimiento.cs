﻿using LogicaNegocio.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using LogicaNegocio.Excepciones;
using Microsoft.VisualBasic;

namespace LogicaNegocio.Entidades
{
    public class Mantenimiento : IValidar
    {
        public static int UltimoId { get; set; }
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public DescripcionMantenimiento descripcionMan { get; set; }
        public Costo Costo { get; set; }
        public string Nombre { get; set; }

        [ForeignKey(nameof(Cabania))] public int IdCaba { get; set; }
        public Cabania Cabania { get; set; }


        public Mantenimiento(DateTime fecha, DescripcionMantenimiento descripcion, Costo costo, string nombre, int caba)
        {
            this.Id = UltimoId;
            Fecha = fecha;
            descripcionMan = descripcion;
            Costo = costo;
            Nombre = nombre;
            IdCaba = caba;
        }
        public Mantenimiento()
        {
           
        }
    
        public void Validar(IConfiguracionRepositorio c)
        {
           this.descripcionMan.Validar(c);
            if (Fecha >= DateTime.Now.Date)
            {
                throw new InvalidMantenimientoException("La fecha no puede ser un dia proximo al dia de hoy");
            }

            if (string.IsNullOrEmpty(Nombre))
            {
                throw new InvalidMantenimientoException("El nombre del mantenimiento no puede estar vacío.");
            }

          this.Costo.Validar(c);
            if(IdCaba==0)
            {
                throw new InvalidMantenimientoException("El Id de la cabaña no puede ser 0.");
            }
            

        }

        
    } 
}
