﻿using LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Interfaces
{
    public interface ICabaniaRepositorio:IRepositorio<Cabania>
    {
        public IEnumerable<Cabania> GetCabaniasPorNombre(string nombre);
        public IEnumerable<Cabania> GetCabaniasPorTipo(string Nombre);
        public IEnumerable<Cabania> GetCabaniasPorCantPersonas(int cant);
        public IEnumerable<Cabania> GetCabaniasHabilitadas();
        public Cabania GetPorNombre(string nombre);
        public IEnumerable<Cabania> GetCabaniaPorNombreTipoYMonto(string nombre, int monto);
        
    }
}
