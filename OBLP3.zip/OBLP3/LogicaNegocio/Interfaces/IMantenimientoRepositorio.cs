﻿using LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Interfaces
{
    public interface IMantenimientoRepositorio:IRepositorio<Mantenimiento>
    {
        public IEnumerable<Mantenimiento> ListEntreFechas(DateTime f1, DateTime f2,int IdHabitacion);
        public Cabania GetCabaniaDeMantenimiento(int id);
        public IEnumerable<Mantenimiento> GetMantenimientosPorMontos(int m1, int m2);
        public Mantenimiento GetPorId(int id);

    }
}
