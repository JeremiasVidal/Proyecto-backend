﻿using LogicaNegocio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Interfaces
{
    public interface ITipoCabaniaRepositorio : IRepositorio<TipoCabania>
    {
        public void Edit(string Nombre, string desc, CostoHuesped costoHuesped);
        public TipoCabania GetPorNombre(string nombre);
    }
}
