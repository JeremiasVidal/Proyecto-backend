﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Excepciones
{
    public class InvalidCabaniaException : Exception
    {
        public InvalidCabaniaException()
        {
        }

        public InvalidCabaniaException(string? message) : base(message)
        {
        }

        public InvalidCabaniaException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        
    }
}
