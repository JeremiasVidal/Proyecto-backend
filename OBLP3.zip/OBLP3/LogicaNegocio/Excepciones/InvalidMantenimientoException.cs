﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Excepciones
{
    public class InvalidMantenimientoException : Exception
    {
        public InvalidMantenimientoException()
        {
        }

        public InvalidMantenimientoException(string? message) : base(message)
        {
        }

        public InvalidMantenimientoException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

       
    }
}
