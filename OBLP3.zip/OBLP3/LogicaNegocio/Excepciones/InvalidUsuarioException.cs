﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio.Excepciones
{
    public class InvalidUsuarioException : Exception
    {
        public InvalidUsuarioException()
        {
        }

        public InvalidUsuarioException(string? message) : base(message)
        {
        }

        public InvalidUsuarioException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}
