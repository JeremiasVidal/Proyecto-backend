﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using NuGet.Common;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using WEBOBLP3.Models;

namespace WEBOBLP3.Controllers
{
    public class CabaniaController : Controller
    {
        private string localhost = "https://localhost:7079/";
        private IWebHostEnvironment _environment;

        public CabaniaController(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        public IActionResult Index()
        {
            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar");

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }

        [HttpPost]
        public IActionResult Index(string nombre)
        {
            try
            {


                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar/filtros/nombre/" + nombre);

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }



        public IActionResult Create()
        {

            if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                return RedirectToAction("Login", "Login");
            try
            {
                ViewBag.Tipos = GetTiposCabanias();

                return View();

            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }






        }




        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult Create(CabaniaModel cab, IFormFile imagen)
        {
            try
            {
                HttpClient cliente = new HttpClient();

                /******************* HEADERS *******************/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /******************* END HEADERS *******************/

                Uri uri = new Uri("https://localhost:7079/Cabania/Crear");
                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Post, uri);

                GuardarImagen(imagen, cab);

                /******************* CONTENIDO O BODY ********************/
                string json = JsonConvert.SerializeObject(cab);
                HttpContent contenido =
                new StringContent(json, Encoding.UTF8, "application/json");
                solicitud.Content = contenido;
                /*************** END CONTENIDO O BODY ********************/

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                if (respuesta.Result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index", "Cabania");
                }
                else if (respuesta.Result.StatusCode == HttpStatusCode.BadRequest)
                {
                    ViewBag.msg = "Error Datos" + response.Result;
                }
                else
                {
                    ViewBag.msg = response.Result;
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
            }
            ViewBag.Tipos = GetTiposCabanias();
            return View();

        }
        private void GuardarImagen(IFormFile imagen, CabaniaModel ca)
        {
            if (imagen == null || ca == null) throw new Exception("Datos incorrectos");

            // Verificar que la extensión de archivo sea permitida
            string extension = Path.GetExtension(imagen.FileName);
            if (extension.ToLower() != ".jpg" && extension.ToLower() != ".png")
            {
                throw new Exception("Tipo de archivo no permitido");
            }

            string rutaFisicaWwwRoot = _environment.WebRootPath;

            // Reemplazar espacios embebidos en el nombre de la cabaña con sub-guión
            string nombreCabaña = ca.Nombre.Replace(" ", "");

            // Buscar la última imagen agregada para la misma cabaña
            int ultimoSecuenciador = 0;
            foreach (var c in GetCabanias())
            {
                if (!string.IsNullOrEmpty(c.Foto))
                {
                    string nombreFoto = Path.GetFileNameWithoutExtension(c.Foto);
                    int guionBajoIndex = nombreFoto.LastIndexOf("_");
                    if (guionBajoIndex != -1)
                    {
                        string nombreCabañaImagen = nombreFoto.Substring(0, guionBajoIndex);

                        string secuenciador = nombreFoto.Substring(guionBajoIndex + 1);
                        int secuenciadorNumero;
                        if (int.TryParse(secuenciador, out secuenciadorNumero))
                        {
                            if (ultimoSecuenciador < secuenciadorNumero)
                            {
                                ultimoSecuenciador = secuenciadorNumero;
                            }
                        }

                    }
                }
            }

            // Incrementar el secuenciador en 1
            int nuevoSecuenciador = ultimoSecuenciador + 1;

            // Agregar secuenciador al final del nombre de la imagen
            string nombreImagen = $"{nombreCabaña}_{nuevoSecuenciador:D3}{extension}";

            // Guardar la imagen en la carpeta de imágenes
            string rutaCompleta = Path.Combine(rutaFisicaWwwRoot, "Imagenes", "Fotos", nombreImagen);
            using (var stream = new FileStream(rutaCompleta, FileMode.Create))
            {
                imagen.CopyTo(stream);
            }

            // Actualizar la propiedad "Foto" de la cabaña
            ca.Foto = nombreImagen;

        }





        public IEnumerable<CabaniaModel> GetCabanias()
        {
            HttpClient cliente = new HttpClient();

            /******************* HEADERS *******************/
            cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
            /******************* END HEADERS *******************/

            Uri uri = new Uri(localhost + "Cabania/Listar");
            HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

            Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
            respuesta.Wait();
            if (respuesta.Result.IsSuccessStatusCode)
            {
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                return ret;

            }
            return null;
        }









        public IEnumerable<TipoCabaniaModel> GetTiposCabanias()
        {
            HttpClient cliente = new HttpClient();

            /******************* HEADERS *******************/
            cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
            /******************* END HEADERS *******************/

            Uri uri = new Uri(localhost + "TipoCabania/Listar");
            HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

            Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
            respuesta.Wait();
            if (respuesta.Result.IsSuccessStatusCode)
            {
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                IEnumerable<TipoCabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<TipoCabaniaModel>>(response.Result);
                return ret;

            }
            return null;
        }


     
        public IActionResult CabaniasHabilitadas()
        {
            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar/filtros/habilitada");

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }

        public IActionResult CabaniasPorCantPersonas()
        {

            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar/");

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }

        [HttpPost]
        public IActionResult CabaniasPorCantPersonas(int cant)
        {

            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar/filtros/Personas/" + cant);

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }



        public IActionResult CabaniasPorTipo()
        {

            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar/");

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }

        [HttpPost]
        public IActionResult CabaniasPorTipo(string nombre)
        {

            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar/filtros/tipo/" + nombre);

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }










        public IActionResult Listar()
        {
            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar");

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }



        public IActionResult CabaniasPorMontoYNombre()
        {


            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar");

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }


        [HttpPost]
        public IActionResult CabaniasPorMontoYNombre(int monto, string nombre)
        {


            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "Cabania/Listar/filtros/TipoMonto/" + nombre + "/" + monto);

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<CabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<CabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }

    }
}






