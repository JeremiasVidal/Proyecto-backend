﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using WEBOBLP3.Models;

namespace WEBOBLP3.Controllers
{
    public class TipoCabaniaController : Controller
    {

        private string localhost = "https://localhost:7079/";


        public IActionResult Create()
        {

            if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                return RedirectToAction("Login", "Login");

            else
            {
                return View();

            }

        }
        [HttpPost]
        public IActionResult Create(TipoCabaniaModel tipo)
        {

            try
            {
                HttpClient cliente = new HttpClient();

                /******************* HEADERS *******************/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /******************* END HEADERS *******************/

                Uri uri = new Uri(localhost + "TipoCabania/Crear");
                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Post, uri);

                /******************* CONTENIDO O BODY ********************/
                string json = JsonConvert.SerializeObject(tipo);
                HttpContent contenido =
                new StringContent(json, Encoding.UTF8, "application/json");
                solicitud.Content = contenido;
                /*************** END CONTENIDO O BODY ********************/

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                if (respuesta.Result.IsSuccessStatusCode)
                {
                    ViewBag.msg = "Tipo Cabaña creado con éxito";
                    return View();
                }
                else if (respuesta.Result.StatusCode == HttpStatusCode.BadRequest)
                {
                    ViewBag.msg = "Error Datos" + response.Result;
                }
                else
                {
                    ViewBag.msg = "Ocurrió un error ";
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
            }
            return View();

        }




        public IActionResult Index()
        {
            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                {
                    return RedirectToAction("Login", "Login");
                }

                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "TipoCabania/Listar");

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<TipoCabaniaModel> ret = JsonConvert.DeserializeObject<IEnumerable<TipoCabaniaModel>>(response.Result);
                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "Ocurrió un error al obtener la lista de cabañas.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }




        [HttpPost]
        public IActionResult Index(string nombre)
        {
            try
            {


                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "TipoCabania/Listar/nombre/" + nombre);

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    TipoCabaniaModel tipo = JsonConvert.DeserializeObject<TipoCabaniaModel>(response.Result);
                    IEnumerable<TipoCabaniaModel> ret = new List<TipoCabaniaModel> { tipo };


                    return View(ret);
                }
                else
                {

                    ViewBag.msg = "No existe el tipo Cabania";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }






        public IActionResult Delete(string nombre)
        {
            try
            {


                HttpClient cliente = new HttpClient();

                /** HEADERS **/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /** END HEADERS **/

                Uri uri = new Uri(localhost + "TipoCabania/Listar/nombre/" + nombre);

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    TipoCabaniaModel tipo = JsonConvert.DeserializeObject<TipoCabaniaModel>(response.Result);
                    return View(tipo);
                }
                else
                {

                    ViewBag.msg = "Tipo Cabania en uso";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }

        }






        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(TipoCabaniaModel tipocab)
        {
            try
            {
                HttpClient cliente = new HttpClient();

                /******* HEADERS *******/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /******* END HEADERS *******/

                Uri uri = new Uri(localhost + "TipoCabania/Borrar/" + tipocab.Nombre);
                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Delete, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "TipoCabania");
                }
                return View(tipocab);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return RedirectToAction("Create", new { error = e.Message });
            }
        }


        public IActionResult Edit(string nombre)
        {
            if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                return RedirectToAction("Login", "Login");


            HttpClient cliente = new HttpClient();

            /******************* HEADERS *******************/
            cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
            /******************* END HEADERS *******************/

            Uri uri = new Uri(localhost + "TipoCabania/Listar/nombre/" + nombre);
            HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

            Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
            respuesta.Wait();
            Task<string> response = respuesta.Result.Content.ReadAsStringAsync();

            TipoCabaniaModel tipocab = JsonConvert.DeserializeObject<TipoCabaniaModel>(response.Result);

            return View(tipocab);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TipoCabaniaModel tipo)
        {
            try
            {
                HttpClient cliente = new HttpClient();

                /******************* HEADERS *******************/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /******************* END HEADERS *******************/

                Uri uri = new Uri("https://localhost:7079/TipoCabania/Editar");
                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Put, uri);


                /******************* CONTENIDO O BODY ********************/
                string json = JsonConvert.SerializeObject(tipo);
                HttpContent contenido =
                new StringContent(json, Encoding.UTF8, "application/json");
                solicitud.Content = contenido;
                /*************** END CONTENIDO O BODY ********************/

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                if (respuesta.Result.IsSuccessStatusCode)
                {

                    return RedirectToAction("Index", "TipoCabania");
                }
                else if (respuesta.Result.StatusCode == HttpStatusCode.BadRequest)
                {
                    ViewBag.msg = "Error Datos" + response.Result;
                }
                else
                {
                    ViewBag.msg = response.Result;
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
            }
            return View();
        }






    }

}

