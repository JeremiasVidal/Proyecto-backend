﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using WEBOBLP3.Models;

namespace WEBOBLP3.Controllers
{
    public class MantenimientoController : Controller
    {
        private string localhost = "https://localhost:7079/";

        public IActionResult GetMantenimientosEntreFechas(int idHabitacion)
        {
            if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
            {
                return RedirectToAction("Login", "Login");
            }
            ViewBag.Id = idHabitacion;
            return View();
        }

        [HttpPost]
        public IActionResult GetMantenimientosEntreFechas(DateTime f1, DateTime f2, int idHabitacion)
        {
            try
            {
                HttpClient cliente = new HttpClient();

                /* HEADERS */
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /* END HEADERS */

                UriBuilder uriBuilder = new UriBuilder(localhost);
                uriBuilder.Path = $"Mantenimiento/Listar/filtro/fechas/{f1.ToString("yyyy-MM-ddTHH:mm:ss")}/{f2.ToString("yyyy-MM-ddTHH:mm:ss")}/{idHabitacion}";

                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uriBuilder.Uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();
                ViewBag.Id = idHabitacion;

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<MantenimientoModel> ret = JsonConvert.DeserializeObject<IEnumerable<MantenimientoModel>>(response.Result);
                    return View(ret);
                }
                else
                {
                    ViewBag.msg = "Ocurrió un error al obtener la lista de mantenimientos.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }


        public IActionResult Create(int idHabitacion)
        {
            try
            {
                if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
                    return RedirectToAction("Login", "Login");
                CabaniaModel ret = GetCabaniaDeMantenimiento(idHabitacion);
                ViewBag.caba = ret;
                ViewBag.Id = ret.IdHabitacion;
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }


        }




        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult Create(MantenimientoModel man)
        {
            try
            {
                HttpClient cliente = new HttpClient();

                /******************* HEADERS *******************/
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /******************* END HEADERS *******************/

                Uri uri = new Uri("https://localhost:7079/Mantenimiento/Crear");
                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Post, uri);

                /******************* CONTENIDO O BODY ********************/
                string json = JsonConvert.SerializeObject(man);
                HttpContent contenido =
                new StringContent(json, Encoding.UTF8, "application/json");
                solicitud.Content = contenido;
                /*************** END CONTENIDO O BODY ********************/

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                ViewBag.Id = man.IdCaba;
                if (respuesta.Result.IsSuccessStatusCode)
                {
                    ViewBag.caba = GetCabaniaDeMantenimiento(man.IdCaba);
                    ViewBag.msg = "Mantenimiento creado con exito";
                    return View();
                }
                else if (respuesta.Result.StatusCode == HttpStatusCode.BadRequest)
                {
                    ViewBag.msg = "Error Datos" + response.Result;
                }
                else
                {
                    ViewBag.msg = response.Result;
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
            }
            ViewBag.caba = GetCabaniaDeMantenimiento(man.IdCaba);
            return View();

        }

        public CabaniaModel GetCabaniaDeMantenimiento(int id)
        {
            HttpClient cliente = new HttpClient();

            /******************* HEADERS *******************/
            cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
            /******************* END HEADERS *******************/

            Uri uri = new Uri(localhost + "Mantenimiento/Cabania/" + id);
            HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

            Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
            respuesta.Wait();
            Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
            if (respuesta.Result.IsSuccessStatusCode)
            {

                CabaniaModel ret = JsonConvert.DeserializeObject<CabaniaModel>(response.Result);


                return ret;
            }

            else
            {

                throw new Exception(response.Result);
            }



        }



        public IActionResult ListarMantenimientosPorMontos()
        {
            if (String.IsNullOrEmpty(HttpContext.Session.GetString("token")))
            {
                return RedirectToAction("Login", "Login");
            }

            return View();
        }


        [HttpPost]
        public IActionResult ListarMantenimientosPorMontos(int m1, int m2)
        {
            try
            {
                HttpClient cliente = new HttpClient();

                /* HEADERS */
                cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", HttpContext.Session.GetString("token"));
                /* END HEADERS */
                Uri uri = new Uri(localhost + "Mantenimiento/filtro/monto/" + m1 + "/" + m2);
                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Get, uri);

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();


                if (respuesta.Result.IsSuccessStatusCode)
                {
                    Task<string> response = respuesta.Result.Content.ReadAsStringAsync();
                    IEnumerable<MantenimientoModel> ret = JsonConvert.DeserializeObject<IEnumerable<MantenimientoModel>>(response.Result);
                    return View(ret);
                }
                else
                {
                    ViewBag.msg = "Ocurrió un error al obtener la lista de mantenimientos.";
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "Error: " + ex.Message;
                return View();
            }
        }




       
    }




}


