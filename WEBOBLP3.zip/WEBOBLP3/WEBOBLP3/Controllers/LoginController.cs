﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using WEBOBLP3.Models;

namespace WEBOBLP3.Controllers
{
    public class LoginController : Controller
    {
        private string localhost = "https://localhost:7079/";
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Login(UsuarioModel usuario)
        {
            try
            {

                HttpClient cliente = new HttpClient();

                /******************* HEADERS *******************/
                Uri uri = new Uri(localhost + "Login");
                HttpRequestMessage solicitud = new HttpRequestMessage(HttpMethod.Post, uri);

                /******************* CONTENIDO O BODY ********************/
                string json = JsonConvert.SerializeObject(usuario);
                HttpContent contenido =
                new StringContent(json, Encoding.UTF8, "application/json");
                solicitud.Content = contenido;
                /*************** END CONTENIDO O BODY ********************/

                Task<HttpResponseMessage> respuesta = cliente.SendAsync(solicitud);
                respuesta.Wait();

           
                Task<string> response = respuesta.Result.Content.ReadAsStringAsync();

                if (respuesta.Result.IsSuccessStatusCode)
                {
                    UsuarioModel usuarioModel = JsonConvert.DeserializeObject<UsuarioModel>(response.Result);
                    HttpContext.Session.SetString("token", usuarioModel.token);

                    return RedirectToAction("Index", "Cabania");
                }
                else if (respuesta.Result.StatusCode == HttpStatusCode.BadRequest)
                {
                    ViewBag.msg = "Usuario o contraseña incorrecta";
                    return View();
                }
                else 
                {
                    ViewBag.msg = "Error en la base de datos";
                    return View();
                }
               
            }
            catch (Exception e)
            {
                ViewBag.msg = "Error: " + e.Message;
                return View();
            }
        }



        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");


        }


    }
}

