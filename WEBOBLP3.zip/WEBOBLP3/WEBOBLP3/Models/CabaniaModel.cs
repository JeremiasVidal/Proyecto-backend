﻿namespace WEBOBLP3.Models
{
    public class CabaniaModel
    {

        public int IdHabitacion { get; set; }
        public string Nombre { get; set; }
        public string NombreTipo { get; set; }
        public TipoCabaniaModel Tipo { get; set; }
        public string Descripcion { get; set; }
        public bool Jacuzzi { get; set; }
        public bool Habilitada { get; set; }
        public int CantPersonas { get; set; }
        public string? Foto { get; set; }
    }
}

