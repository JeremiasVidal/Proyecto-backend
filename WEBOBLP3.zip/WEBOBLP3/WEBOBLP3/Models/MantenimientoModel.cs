﻿namespace WEBOBLP3.Models
{
    public class MantenimientoModel
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public string Descripcion { get; set; }
        public int Costo { get; set; }
        public string Nombre { get; set; }
        public int IdCaba { get; set; }
        public CabaniaModel Cabania { get; set; }
    }
}

