﻿namespace WEBOBLP3.Models
{
    public class TipoCabaniaModel
    {

        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public int CostoHuesped { get; set; }
    }
}
