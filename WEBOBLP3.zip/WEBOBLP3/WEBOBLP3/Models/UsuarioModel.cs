﻿using System.ComponentModel.DataAnnotations;

namespace WEBOBLP3.Models
{
    public class UsuarioModel
    {
        public string token { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

  
    }
}
